﻿/*YTD - BOM - PhaiSinh*/

/*Trailing - Market Share (So sánh 5 năm gần nhất) */

BEGIN


DECLARE @Date DATETIME;
SET @Date = @YYYYMMDD;

DECLARE @Since DATETIME;
SET @Since = DATETIMEFROMPARTS(YEAR(@Date)-4,1,1,0,0,0,0);


WITH 

[MarketTradingValue] AS (
	SELECT
		DATETIMEFROMPARTS(YEAR([Ngay]),12,31,0,0,0,0) [Date]
		, SUM(ISNULL([KhoiLuongKhopLenh],0) + ISNULL([KhoiLuongThoaThuan],0)) [TotalContracts]
	FROM [DWH-ThiTruong].[dbo].[KetQuaGiaoDichPhaiSinhVietStock]
	WHERE [Ngay] BETWEEN @Since AND @Date 
	GROUP BY DATETIMEFROMPARTS(YEAR([Ngay]),12,31,0,0,0,0)
)

, [BranchList] AS (
	SELECT [BranchID]
	FROM [BranchTargetByYear] 
	WHERE [Year] = YEAR(@Date)
		AND [Measure] = 'Market Share'
)

, [YearlyTarget] AS (
   SELECT 
        [Year]
        , CAST(SUM([Target]) AS DECIMAL(20,7)) [Target]
    FROM [BranchTargetByYear] 
	WHERE [Year] BETWEEN YEAR(@Since) AND YEAR(@Date)
        AND [Measure] = 'Market Share'
	GROUP BY [Year]
)

, [Rel] AS (
    SELECT DISTINCT
		[date] [Date]
 		, [branch_id] [BranchID]
		, [broker_id] [BrokerID]
		, [account_code] [AccountCode]
	FROM [relationship]
    WHERE [date] BETWEEN @Since AND @Date
)

, [ValueAllBranchesByDate] AS (
	SELECT
		DATETIMEFROMPARTS(YEAR([RRE0018].[Ngay]),12,31,0,0,0,0) [Date]
		, ISNULL(SUM([RRE0018].[SoLuongHopDong]), 0) [Value]
	FROM [RRE0018]
	LEFT JOIN [Rel]
        ON [Rel].[AccountCode] = [RRE0018].[SoTaiKhoan]
		AND [Rel].[Date] = [RRE0018].[Ngay]
	WHERE [RRE0018].[Ngay] BETWEEN @Since AND @Date
		AND [Rel].[BranchID] IN (SELECT [BranchID] FROM [BranchList])
	GROUP BY DATETIMEFROMPARTS(YEAR([RRE0018].[Ngay]),12,31,0,0,0,0)
)
SELECT
	DATETIMEFROMPARTS([YearlyTarget].[Year],12,31,0,0,0,0) [Date]
	, ISNULL([ValueAllBranchesByDate].[Value] / [MarketTradingValue].[TotalContracts] / 2, 0) [Actual]
	, ISNULL([YearlyTarget].[Target], 0) [Target]
FROM [YearlyTarget]
LEFT JOIN [ValueAllBranchesByDate]
	ON YEAR([ValueAllBranchesByDate].[Date]) = [YearlyTarget].[Year]
LEFT JOIN [MarketTradingValue]
	ON [ValueAllBranchesByDate].[Date] = [MarketTradingValue].[Date]
ORDER BY 1


END